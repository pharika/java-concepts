
public class student {
	  
		 int rollno;  
		 String name;  
		 String city;  
		  
		 student(int rollno, String name, String city){  
		 this.rollno=rollno;  
		 this.name=name;  
		 this.city=city;  
		 }  
		  
		 public static void main(String args[]){  
			 Students s1=new Students(1,"Ram","chennai");  
			   Students s2=new Students(2,"raj","hydrabad");  
			     
		   System.out.println(s1); 
		   System.out.println(s2);  
		 }  
		}  


