
public class Students{  
 int rollno;  
 String name;  
 String city;  
  
 Students(int rollno, String name, String city){  
 this.rollno=rollno;  
 this.name=name;  
 this.city=city;  
 }  
   
 public String toString(){//overriding the toString() method  
  return rollno+" "+name+" "+city;  
 }  
 public static void main(String args[]){  
   Students s1=new Students(1,"Ram","chennai");  
   Students s2=new Students(2,"raj","hydrabad");  
     
   System.out.println(s1); 
   System.out.println(s2);  
 }  
}  
