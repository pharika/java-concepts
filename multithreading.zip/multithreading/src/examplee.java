
class exam extends Thread {
	public void run() {
		for (int i = 0; i <= 5; i++) {
			System.out.println(Thread.currentThread().getName() + ": " + i);
		}
	}

}

public class examplee {
	public static void main(String[] args) {
		Thread t1 = new exam();
		Thread t2 = new exam();
		Thread t3 = new exam();
		t1.start();
		t2.start();
		t3.start();

	}
}