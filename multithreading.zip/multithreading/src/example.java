public class example implements Runnable{
 
    public static void main(String[] args) {
        Thread Thread1 = new Thread("thread is running:1");
        Thread Thread2 = new Thread("thread is running:2");
        Thread1.start();
        Thread2.start();
        System.out.println("Thread names are following:");
        System.out.println(Thread1.getName());
        System.out.println(Thread2.getName());
    }
    public void run() {
    }
 
}