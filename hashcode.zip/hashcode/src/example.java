import java.util.Scanner;  
public class example {  
    public static void main(String[] args) {  
     
      System.out.print("Enter the input value: ");  
      Scanner readInput = new Scanner(System.in);         
        Integer i = readInput.nextInt();  
        readInput.close();     
        int hashValue = Integer.hashCode(i);  
        System.out.println("Hash code Value for object is: " + hashValue);  
        }  
}  