public class student {
	  
		 int rollno;  
		 String name;  
		 String city;  
		  
		 student(int rollno, String name, String city){  
		 this.rollno=rollno;  
		 this.name=name;  
		 this.city=city;  
		 }  
		  
		 public static void main(String args[]){  
			 student s1=new student(1,"Ram","chennai");  
			   student s2=new student(2,"raj","hydrabad");  
			     
		   System.out.println(s1); 
		   System.out.println(s2);  
		 }  
		}  