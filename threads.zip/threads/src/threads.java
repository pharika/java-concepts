class threads implements Runnable{  
public void run(){  
System.out.println("thread is running...");  
}  
  
public static void main(String args[]){  
threads t=new threads();  
Thread t1 =new Thread(t);  
t1.start();  
 }  
}  